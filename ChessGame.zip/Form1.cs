﻿using ChessShared;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace ChessClientFinal
{
    public partial class Form1 : Form
    {
        private ChessBoard game;
        private Button[,] buttons;

        private int selectedRow = -1;
        private int selectedCol = -1;

        private TcpClient client;
        private Json json;

        private PieceColor myColor;
        private bool myTurn;

        private Label statusLabel;

        private static readonly Color LightSquare = Color.FromArgb(240, 217, 181);
        private static readonly Color DarkSquare = Color.FromArgb(181, 136, 99);
        private static readonly Color SelectedColor = Color.FromArgb(60, 200, 60);
        private static readonly Color MoveColor = Color.FromArgb(120, 220, 120);

        public Form1()
        {
            InitializeComponent();
            InitializeBoard();
        }

        private void InitializeBoard()
        {
            this.Text = "Chess Client";
            this.Size = new Size(600, 700);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            statusLabel = new Label
            {
                Text = "Connecting...",
                Location = new Point(10, 10),
                Size = new Size(500, 30),
                Font = new Font("Arial", 12, FontStyle.Bold)
            };
            this.Controls.Add(statusLabel);

            buttons = new Button[8, 8];

            int size = 60;

            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    var btn = new Button
                    {
                        Size = new Size(size, size),
                        Location = new Point(c * size + 10, r * size + 50),
                        Font = new Font("Segoe UI Symbol", 22),
                        FlatStyle = FlatStyle.Flat,
                        Tag = (r, c)
                    };

                    btn.FlatAppearance.BorderSize = 0;
                    btn.Click += OnSquareClick;

                    buttons[r, c] = btn;
                    this.Controls.Add(btn);
                }
            }

            this.Load += (s, e) => ConnectToServer();
        }

        private void ConnectToServer()
        {
            try
            {
                client = new TcpClient("127.0.0.1", 5000);
                json = new Json(client.GetStream());

                new Thread(ReceiveLoop) { IsBackground = true }.Start();

                UpdateStatus("Connected. Waiting for opponent...");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection failed: " + ex.Message);
            }
        }

        private void ReceiveLoop()
        {
            try
            {
                while (true)
                {
                    NetMessage msg;

                    try
                    {
                        msg = json.Receive<NetMessage>();
                    }
                    catch
                    {
                        break;
                    }

                    if (msg == null)
                        break;

                    Invoke((Action)(() => HandleMessage(msg)));
                }
            }
            catch (Exception ex)
            {
                Invoke((Action)(() =>
                    UpdateStatus("Connection lost: " + ex.Message)
                ));
            }
        }

        private void HandleMessage(NetMessage msg)
        {
            if (msg.Type == "Color")
            {
                myColor = msg.Data.ToString() == "White"
                    ? PieceColor.White
                    : PieceColor.Black;

                UpdateStatus("You are " + myColor);
            }
            else if (msg.Type == "Start")
            {
                game = new ChessBoard();
                myTurn = (myColor == PieceColor.White);

                DrawBoard();

                UpdateStatus(myTurn ? "Your turn" : "Opponent's turn");
            }
            else if (msg.Type == "Move")
            {
                var move = JsonConvert.DeserializeObject<Move>(msg.Data.ToString());

                game.TryMove(move.FromRow, move.FromCol, move.ToRow, move.ToCol);

                myTurn = true;

                CheckGameState();
                DrawBoard();
            }
            else if (msg.Type == "Disconnect")
            {
                MessageBox.Show("Opponent disconnected");
                game = null;
            }
        }

        private void OnSquareClick(object sender, EventArgs e)
        {
            if (game == null || !myTurn || game.IsGameOver) return;

            var (r, c) = ((int, int))((Button)sender).Tag;

            if (selectedRow == -1)
            {
                var piece = game.Board[r, c];

                if (piece != null && piece.Color == myColor)
                {
                    selectedRow = r;
                    selectedCol = c;

                    HighlightMoves(r, c);
                }
            }
            else
            {
                bool moved = game.TryMove(selectedRow, selectedCol, r, c);

                if (moved)
                {
                    SendMove(selectedRow, selectedCol, r, c);
                    myTurn = false;

                    CheckGameState();
                }

                selectedRow = -1;
                selectedCol = -1;

                DrawBoard();
            }
        }

        private void SendMove(int fr, int fc, int tr, int tc)
        {
            json.Send(new NetMessage
            {
                Type = "Move",
                Data = new Move
                {
                    FromRow = fr,
                    FromCol = fc,
                    ToRow = tr,
                    ToCol = tc
                }
            });
        }

        private void DrawBoard()
        {
            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    var piece = game.Board[r, c];
                        
                    buttons[r, c].Text = piece?.Symbol() ?? "";

                    buttons[r, c].BackColor =
                        ((r + c) % 2 == 0) ? LightSquare : DarkSquare;
                }
            }

            if (game != null &&
                MoveValidatorr.IsKingInCheck(game, game.CurrentTurn))
            {
                for (int r = 0; r < 8; r++)
                    for (int c = 0; c < 8; c++)
                    {
                        var p = game.Board[r, c];
                        if (p?.Type == PieceType.King &&
                            p.Color == game.CurrentTurn)
                        {
                            buttons[r, c].BackColor = Color.Red;
                        }
                    }
            }
        }

        private void HighlightMoves(int r, int c)
        {
            DrawBoard();

            buttons[r, c].BackColor = SelectedColor;

            var moves = MoveValidatorr.GetLegalMoves(game, r, c);

            foreach (var (mr, mc) in moves)
            {
                buttons[mr, mc].BackColor = MoveColor;
            }
        }

        private void CheckGameState()
        {
            if (game == null) return;

            PieceColor opponent = myColor == PieceColor.White
                ? PieceColor.Black
                : PieceColor.White;

            bool check = MoveValidatorr.IsKingInCheck(game, opponent);
            bool moves = MoveValidatorr.HasAnyLegalMoves(game, opponent);

            if (!moves)
            {
                game.IsGameOver = true;

                game.GameResult = check
                    ? "Checkmate!"
                    : "Stalemate!";

                MessageBox.Show(game.GameResult);
            }
            else if (check)
            {
                UpdateStatus("CHECK!");
            }
        }

        private void UpdateStatus(string text)
        {
            statusLabel.Text = text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}