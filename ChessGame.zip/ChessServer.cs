﻿using ChessShared;
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ChessShared
{
    class ChessServer
    {
        static TcpClient w, b;
        static Json nw, nb;

        static void Main()
        {
            var server = new TcpListener(IPAddress.Any, 5000);
            server.Start();

            w = server.AcceptTcpClient();
            nw = new Json(w.GetStream());
            nw.Send(new NetMessage { Type = "Color", Data = "White" });

            b = server.AcceptTcpClient();
            nb = new Json(b.GetStream());
            nb.Send(new NetMessage { Type = "Color", Data = "Black" });

            nw.Send(new NetMessage { Type = "Start" });
            nb.Send(new NetMessage { Type = "Start" });

            new Thread(() => Relay(nw, nb)).Start();
            new Thread(() => Relay(nb, nw)).Start();

            Console.ReadLine();
        }


        static void Relay(Json from, Json to)
        {
            try
            {
                while (true)
                {
                    NetMessage msg = null;

                    try
                    {
                        msg = from.Receive<NetMessage>();
                    }
                    catch
                    {
                        break; 
                    }

                    if (msg == null)
                        break;

                    try
                    {
                        to.Send(msg);
                    }
                    catch
                    {
                        break;
                    }
                }
            }
            catch
            {
               
            }
        }
    }
    }