﻿

namespace ChessClientFinal
{
    public enum PieceType
    {
        None,   
        Rook,
        Knight,
        Bishop,
        Queen,
        Pawn,
        King
        
    }

    public enum PieceColor
    {
        None,   
        White,
        Black
    }

    public class ChessPiece
    {
        public PieceType Type { get; set; }
        public PieceColor Color { get; set; }

        public bool HasMoved { get; set; } = false;

        public ChessPiece(PieceType type, PieceColor color)
        {
            Type = type;
            Color = color;
        }

        public string Symbol()
        {
            if (Color == PieceColor.White)
            {
                switch (Type)
                {
                    case PieceType.King: return "♔";
                    case PieceType.Queen: return "♕";
                    case PieceType.Rook: return "♖";
                    case PieceType.Bishop: return "♗";
                    case PieceType.Knight: return "♘";
                    case PieceType.Pawn: return "♙";
                }
            }
            else
            {
                switch (Type)
                {
                    case PieceType.King: return "♚";
                    case PieceType.Queen: return "♛";
                    case PieceType.Rook: return "♜";
                    case PieceType.Bishop: return "♝";
                    case PieceType.Knight: return "♞";
                    case PieceType.Pawn: return "♟";
                }
            }
            return "";
        }

        public ChessPiece Clone()
        {
            return new ChessPiece(Type, Color) { HasMoved = HasMoved };
        }
    }
}