﻿namespace ChessShared
{
    public class NetMessage
    {
        public string Type { get; set; }   
        public object Data { get; set; }
    }
}