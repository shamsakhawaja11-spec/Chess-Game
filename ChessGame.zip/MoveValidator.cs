﻿using System.Collections.Generic;
namespace ChessClientFinal
{
    public static class MoveValidatorr
    {
        public static bool HasAnyLegalMoves(ChessBoard game, PieceColor color)
        {
            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    var piece = game.Board[r, c];
                    if (piece != null && piece.Color == color)
                        if (GetLegalMoves(game, r, c).Count > 0)
                            return true;
                }
            }
            return false;
        }
        public static List<(int, int)> GetLegalMoves(ChessBoard game, int r, int c)
        {
            var piece = game.Board[r, c];
            if (piece == null)
                return new List<(int, int)>();

            var moves = GetPseudoMoves(game, r, c);
            var legal = new List<(int, int)>();

            foreach (var move in moves)
            {
                int tr = move.Item1, tc = move.Item2;
                var clone = game.Clone();
                clone.Board[tr, tc] = clone.Board[r, c];
                clone.Board[r, c] = null;
                if (!IsKingInCheck(clone, piece.Color))
                    legal.Add((tr, tc));
            }

            if (piece.Type == PieceType.King && !piece.HasMoved
                && !IsKingInCheck(game, piece.Color))
            {
                int row = piece.Color == PieceColor.White ? 7 : 0;

                if (r == row)
                {
                    var kRook = game.Board[row, 7];
                    if (kRook != null && !kRook.HasMoved
                        && kRook.Type == PieceType.Rook
                        && kRook.Color == piece.Color
                        && game.Board[row, 5] == null
                        && game.Board[row, 6] == null)
                    {
                        var cloneF = game.Clone();
                        cloneF.Board[row, 5] = cloneF.Board[r, c];
                        cloneF.Board[r, c] = null;

                        var cloneG = game.Clone();
                        cloneG.Board[row, 6] = cloneG.Board[r, c];
                        cloneG.Board[r, c] = null;

                        if (!IsKingInCheck(cloneF, piece.Color)
                            && !IsKingInCheck(cloneG, piece.Color))
                            legal.Add((row, 6));
                    }

                    var qRook = game.Board[row, 0];
                    if (qRook != null && !qRook.HasMoved
                        && qRook.Type == PieceType.Rook
                        && qRook.Color == piece.Color
                        && game.Board[row, 1] == null
                        && game.Board[row, 2] == null
                        && game.Board[row, 3] == null)
                    {
                        var cloneD = game.Clone();
                        cloneD.Board[row, 3] = cloneD.Board[r, c];
                        cloneD.Board[r, c] = null;

                        var cloneC = game.Clone();
                        cloneC.Board[row, 2] = cloneC.Board[r, c];
                        cloneC.Board[r, c] = null;

                        if (!IsKingInCheck(cloneD, piece.Color)
                            && !IsKingInCheck(cloneC, piece.Color))
                            legal.Add((row, 2));
                    }
                }
            }

            return legal;
        }
        public static bool IsKingInCheck(ChessBoard game, PieceColor color)
        {
            (int kr, int kc) = FindKing(game, color);
            if (kr == -1) return false;
            for (int r = 0; r < 8; r++)
                for (int c = 0; c < 8; c++)
                {
                    var p = game.Board[r, c];
                    if (p != null && p.Color != color)
                    {
                        var moves = GetPseudoMoves(game, r, c);
                        if (moves.Contains((kr, kc)))
                            return true;
                    }
                }
            return false;
        }

        static (int, int) FindKing(ChessBoard g, PieceColor col)
        {
            for (int r = 0; r < 8; r++)
                for (int c = 0; c < 8; c++)
                    if (g.Board[r, c]?.Type == PieceType.King &&
                        g.Board[r, c]?.Color == col)
                        return (r, c);
            return (-1, -1);
        }

        static List<(int, int)> GetPseudoMoves(ChessBoard g, int r, int c)
        {
            var p = g.Board[r, c];
            var list = new List<(int, int)>();

            if (p.Type == PieceType.Pawn)
            {
                int dir = p.Color == PieceColor.White ? -1 : 1;
                int startRow = p.Color == PieceColor.White ? 6 : 1;

                if (In(r + dir, c) && g.Board[r + dir, c] == null)
                {
                    list.Add((r + dir, c));
                    if (r == startRow && g.Board[r + 2 * dir, c] == null)
                        list.Add((r + 2 * dir, c));
                }
                foreach (int dc in new[] { -1, 1 })
                    if (In(r + dir, c + dc) && g.Board[r + dir, c + dc] != null
                        && g.Board[r + dir, c + dc].Color != p.Color)
                        list.Add((r + dir, c + dc));
            }
            else if (p.Type == PieceType.Rook)
            {
                foreach (var (dr, dc) in new[] { (-1, 0), (1, 0), (0, -1), (0, 1) })
                    for (int i = 1; i < 8; i++)
                    {
                        int nr = r + dr * i, nc = c + dc * i;
                        if (!In(nr, nc)) break;
                        if (g.Board[nr, nc] == null) list.Add((nr, nc));
                        else { if (g.Board[nr, nc].Color != p.Color) list.Add((nr, nc)); break; }
                    }
            }
            else if (p.Type == PieceType.Bishop)
            {
                foreach (var (dr, dc) in new[] { (-1, -1), (-1, 1), (1, -1), (1, 1) })
                    for (int i = 1; i < 8; i++)
                    {
                        int nr = r + dr * i, nc = c + dc * i;
                        if (!In(nr, nc)) break;
                        if (g.Board[nr, nc] == null) list.Add((nr, nc));
                        else { if (g.Board[nr, nc].Color != p.Color) list.Add((nr, nc)); break; }
                    }
            }
            else if (p.Type == PieceType.Queen)
            {
                foreach (var (dr, dc) in new[] { (-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1) })
                    for (int i = 1; i < 8; i++)
                    {
                        int nr = r + dr * i, nc = c + dc * i;
                        if (!In(nr, nc)) break;
                        if (g.Board[nr, nc] == null) list.Add((nr, nc));
                        else { if (g.Board[nr, nc].Color != p.Color) list.Add((nr, nc)); break; }
                    }
            }
            else if (p.Type == PieceType.Knight)
            {
                foreach (var (dr, dc) in new[] { (-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1) })
                {
                    int nr = r + dr, nc = c + dc;
                    if (In(nr, nc) && g.Board[nr, nc]?.Color != p.Color)
                        list.Add((nr, nc));
                }
            }
            else if (p.Type == PieceType.King)
            {
                foreach (var (dr, dc) in new[] { (-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1) })
                {
                    int nr = r + dr, nc = c + dc;
                    if (In(nr, nc) && g.Board[nr, nc]?.Color != p.Color)
                        list.Add((nr, nc));
                }
            }

            return list;
        }

        static bool In(int r, int c) => r >= 0 && r < 8 && c >= 0 && c < 8;
    }
}