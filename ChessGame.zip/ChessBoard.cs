﻿using System; 
namespace ChessClientFinal
{
    public class ChessBoard
    {
        public ChessPiece[,] Board { get; set; } = new ChessPiece[8, 8];
        public PieceColor CurrentTurn { get; set; } = PieceColor.White;
        public (int row, int col)? EnPassantTarget { get; set; }
        public bool IsGameOver { get; set; }
        public string GameResult { get; set; }
        public ChessBoard(bool empty = false)
        {
            if (!empty)
                SetupInitialPosition();
        }

        private void SetupInitialPosition()
        {
            for (int r = 0; r < 8; r++)
                for (int c = 0; c < 8; c++)
                    Board[r, c] = null;

            for (int c = 0; c < 8; c++)
            {
                Board[1, c] = new ChessPiece(PieceType.Pawn, PieceColor.Black);
                Board[6, c] = new ChessPiece(PieceType.Pawn, PieceColor.White);
            }
            Board[0, 0] = new ChessPiece(PieceType.Rook, PieceColor.Black);
            Board[0, 7] = new ChessPiece(PieceType.Rook, PieceColor.Black);
            Board[7, 0] = new ChessPiece(PieceType.Rook, PieceColor.White);
            Board[7, 7] = new ChessPiece(PieceType.Rook, PieceColor.White);

            Board[0, 1] = new ChessPiece(PieceType.Knight, PieceColor.Black);
            Board[0, 6] = new ChessPiece(PieceType.Knight, PieceColor.Black);
            Board[7, 1] = new ChessPiece(PieceType.Knight, PieceColor.White);
            Board[7, 6] = new ChessPiece(PieceType.Knight, PieceColor.White);

            Board[0, 2] = new ChessPiece(PieceType.Bishop, PieceColor.Black);
            Board[0, 5] = new ChessPiece(PieceType.Bishop, PieceColor.Black);
            Board[7, 2] = new ChessPiece(PieceType.Bishop, PieceColor.White);
            Board[7, 5] = new ChessPiece(PieceType.Bishop, PieceColor.White);

            Board[0, 3] = new ChessPiece(PieceType.Queen, PieceColor.Black);
            Board[7, 3] = new ChessPiece(PieceType.Queen, PieceColor.White);

            Board[0, 4] = new ChessPiece(PieceType.King, PieceColor.Black);
            Board[7, 4] = new ChessPiece(PieceType.King, PieceColor.White);
        }

        public bool TryMove(int fr, int fc, int tr, int tc)
        {
            var piece = Board[fr, fc];
            if (piece == null) return false;
            if (piece.Color != CurrentTurn) return false;

            var moves = MoveValidatorr.GetLegalMoves(this, fr, fc);
            if (!moves.Contains((tr, tc))) return false;

            if (piece.Type == PieceType.King && Math.Abs(tc - fc) == 2)
            {
                if (tc == 6) 
                {
                    Board[tr, 5] = Board[tr, 7];
                    Board[tr, 7] = null;
                    if (Board[tr, 5] != null) Board[tr, 5].HasMoved = true;
                }
                else if (tc == 2) 
                {
                    Board[tr, 3] = Board[tr, 0];
                    Board[tr, 0] = null;
                    if (Board[tr, 3] != null) Board[tr, 3].HasMoved = true;
                }
            }

            Board[tr, tc] = piece;
            Board[fr, fc] = null;
            piece.HasMoved = true; 

            CurrentTurn = CurrentTurn == PieceColor.White
                ? PieceColor.Black
                : PieceColor.White;
            PieceColor opponent = CurrentTurn; 
            bool inCheck = MoveValidatorr.IsKingInCheck(this, opponent);
            bool hasMoves = MoveValidatorr.HasAnyLegalMoves(this, opponent);

            if (!hasMoves)
            {
                IsGameOver = true;
                if (inCheck)
                {
                    string winner = opponent == PieceColor.White ? "Black" : "White";
                    GameResult = $"Checkmate! {winner} wins!";
                }
                else
                {
                    GameResult = "Stalemate! It's a draw!";
                }
            }
            return true;
        }
        public ChessBoard Clone()
        {
            var clone = new ChessBoard(true);
            for (int r = 0; r < 8; r++)
                for (int c = 0; c < 8; c++)
                    clone.Board[r, c] = Board[r, c]?.Clone();
            clone.CurrentTurn = CurrentTurn;
            clone.EnPassantTarget = EnPassantTarget;
            clone.IsGameOver = IsGameOver;
            clone.GameResult = GameResult;
            return clone;
        }
    }
}