﻿using System.IO;
using System.Net.Sockets;
using Newtonsoft.Json;

namespace ChessShared
{
    public class Json
    {
        private StreamReader _reader;
        private StreamWriter _writer;

        public Json(NetworkStream stream)
        {
            _reader = new StreamReader(stream);
            _writer = new StreamWriter(stream)
            {
                AutoFlush = true
            };
        }

        public void Send(object obj)
        {
            string json = JsonConvert.SerializeObject(obj);
            _writer.WriteLine(json);
        }

        public T Receive<T>()
        {
            string line = _reader.ReadLine();
            if (string.IsNullOrEmpty(line))
                return default;

            return JsonConvert.DeserializeObject<T>(line);
        }
    }
}